./doit.sh | tee screen.out

